package com.example.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.google.firebase.database.FirebaseDatabase

class UpdateTaskActivity : AppCompatActivity() {

    private lateinit var btnDeleteTask: Button
    private lateinit var taskId: String
    private lateinit var taskNameEditText: EditText
    private lateinit var taskDescriptionEditText: EditText
    private lateinit var database: FirebaseDatabase

    private var selectedTask: Task? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_update_task)

        database = FirebaseDatabase.getInstance()

        // Initialize EditText fields
        taskNameEditText = findViewById(R.id.etTaskName)
        taskDescriptionEditText = findViewById(R.id.etTaskDescription)

        // Get the task data from the previous activity
        taskId = intent.getStringExtra("taskId") ?: ""
        val taskName = intent.getStringExtra("taskName") ?: ""
        val taskDescription = intent.getStringExtra("taskDescription") ?: ""

        // Set the task data to the EditText fields
        taskNameEditText.setText(taskName)
        taskDescriptionEditText.setText(taskDescription)

        btnDeleteTask = findViewById(R.id.btnDeleteTask)

        // Set a click listener for the delete button
        btnDeleteTask.setOnClickListener {
            // Delete the task
            deleteTask(taskId)
        }

        findViewById<Button>(R.id.btnBack).setOnClickListener {
            finish() // Finish the current activity and return to the previous activity (MainActivity)
        }

        // Update task button click listener
        findViewById<Button>(R.id.btnUpdateTask).setOnClickListener {
            val updatedTaskName = taskNameEditText.text.toString()
            val updatedTaskDescription = taskDescriptionEditText.text.toString()

            // Perform the update operation
            updateTask(taskId, updatedTaskName, updatedTaskDescription)
        }
    }

    private fun updateTask(taskId: String, taskName: String, taskDescription: String) {
        val tasksRef = database.getReference("task")
        val taskRef = tasksRef.child(taskId)

        val updatedTask = mapOf(
            "name" to taskName,
            "description" to taskDescription
        )

        taskRef.updateChildren(updatedTask)
            .addOnSuccessListener {
                // Task update succeeded
                Toast.makeText(this, "Task updated successfully", Toast.LENGTH_SHORT).show()
                finish() // Finish the activity and go back to the previous activity
            }
            .addOnFailureListener {
                // Task update failed
                Toast.makeText(this, "Failed to update task", Toast.LENGTH_SHORT).show()
            }
    }
    private fun deleteTask(taskId: String) {
        val tasksRef = database.getReference("task")
        tasksRef.child(taskId).removeValue()
            .addOnSuccessListener {
                // Task deletion succeeded
                Toast.makeText(this, "Task deleted successfully", Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener {
                // Task deletion failed
                Toast.makeText(this, "Failed to delete task", Toast.LENGTH_SHORT).show()
            }
    }

    private fun setCategory(task: Task) {
        selectedTask = task
    }

    private fun getCurrentSelectedTax(): Task? {
        return selectedTask
    }


}

