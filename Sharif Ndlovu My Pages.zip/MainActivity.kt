package com.example.myapplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.google.firebase.FirebaseApp
import com.google.firebase.database.FirebaseDatabase

class MainActivity : AppCompatActivity() {

    private lateinit var database: FirebaseDatabase
    private lateinit var taskNameEditText: EditText
    private lateinit var taskDescriptionEditText: EditText
    private lateinit var taskStartDateEditText: EditText
    private lateinit var taskEndDateEditText: EditText
    private lateinit var categoryNameEditText: EditText
    private lateinit var categoryDescriptionEditText: EditText
    private lateinit var categoryColorEditText: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        FirebaseApp.initializeApp(applicationContext)

        database = FirebaseDatabase.getInstance()

        // Initialize EditText fields
        taskNameEditText = findViewById(R.id.etTaskName)
        taskDescriptionEditText = findViewById(R.id.etTaskDescription)
        taskStartDateEditText = findViewById(R.id.etTaskStartDate)
        taskEndDateEditText = findViewById(R.id.etTaskEndDate)
        categoryNameEditText = findViewById(R.id.etCategoryName)
        categoryDescriptionEditText = findViewById(R.id.etCategoryDescription)
        categoryColorEditText = findViewById(R.id.etCategoryColor)

        // Create task button click listener
        findViewById<Button>(R.id.btnCreateTask).setOnClickListener {
            val task = Task(
                name = taskNameEditText.text.toString(),
                description = taskDescriptionEditText.text.toString(),
                startDate = taskStartDateEditText.text.toString(),
                endDate = taskEndDateEditText.text.toString(),
                imageUrl = "https://example.com/image.jpg"
            )
            createTask(task)
        }

        // Create category button click listener
        findViewById<Button>(R.id.btnCreateCategory).setOnClickListener {
            val category = Category(
                name = categoryNameEditText.text.toString(),
                description = categoryDescriptionEditText.text.toString(),
                color = categoryColorEditText.text.toString()
            )
            createCategory(category)
        }

        // Update task button click listener
        findViewById<Button>(R.id.btnUpdateTask).setOnClickListener {
            val task = Task(
                name = taskNameEditText.text.toString(),
                description = taskDescriptionEditText.text.toString(),
                startDate = taskStartDateEditText.text.toString(),
                endDate = taskEndDateEditText.text.toString(),
                imageUrl = "https://example.com/image.jpg"
            )
            updateTask(task)
        }

        // Update category button click listener
        findViewById<Button>(R.id.btnUpdateCategory).setOnClickListener {
            val category = Category(
                name = categoryNameEditText.text.toString(),
                description = categoryDescriptionEditText.text.toString(),
                color = categoryColorEditText.text.toString()
            )
            updateCategory(category)
        }

        val btnUpdateTask: Button = findViewById(R.id.btnUpdateTask)
        btnUpdateTask.setOnClickListener {
            // Launch Update Task Activity
            val intent = Intent(this, UpdateTaskActivity::class.java)
            startActivity(intent)
        }

        val btnUpdateCategory: Button = findViewById(R.id.btnUpdateCategory)
        btnUpdateCategory.setOnClickListener {
            // Launch Update Category Activity
            val intent = Intent(this, UpdateCategoryActivity::class.java)
            startActivity(intent)
        }
    }


    private fun createTask(task: Task) {
        val tasksRef = database.getReference("task")
        val taskId = tasksRef.push().key ?: return // Generate a new unique key for the task

        tasksRef.child(taskId).setValue(task)
            .addOnSuccessListener {
                // Task creation succeeded
                Toast.makeText(this, "Task created successfully", Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener {
                // Task creation failed
                Toast.makeText(this, "Failed to create task", Toast.LENGTH_SHORT).show()
            }
    }

    private fun createCategory(category: Category) {
        val categoriesRef = database.getReference("category")
        val categoryId = categoriesRef.push().key ?: return // Generate a new unique key for the category

        categoriesRef.child(categoryId).setValue(category)
            .addOnSuccessListener {
                // Category creation succeeded
                Toast.makeText(this, "Category created successfully", Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener {
                // Category creation failed
                Toast.makeText(this, "Failed to create category", Toast.LENGTH_SHORT).show()
            }
    }

    private fun updateTask(task: Task) {
        val tasksRef = database.getReference("task")

        // Assuming you have the taskId of the task you want to update
        val taskId = "taskId" // Replace "taskId" with the actual taskId

        tasksRef.child(taskId).setValue(task)
            .addOnSuccessListener {
                // Task update succeeded
                Toast.makeText(this, "Task updated successfully", Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener {
                // Task update failed
                Toast.makeText(this, "Failed to update task", Toast.LENGTH_SHORT).show()
            }
    }

    private fun updateCategory(category: Category) {
        val categoriesRef = database.getReference("category")

        // Assuming you have the categoryId of the category you want to update
        val categoryId = "categoryId" // Replace "categoryId" with the actual categoryId

        categoriesRef.child(categoryId).setValue(category)
            .addOnSuccessListener {
                // Category update succeeded
                Toast.makeText(this, "Category updated successfully", Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener {
                // Category update failed
                Toast.makeText(this, "Failed to update category", Toast.LENGTH_SHORT).show()
            }
    }
}


data class Task(
    val name: String,
    val description: String,
    val startDate: String,
    val endDate: String,
    val imageUrl: String? = null
)

data class Category(
    val name: String,
    val description: String,
    val color: String
)
