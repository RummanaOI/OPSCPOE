package com.example.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.google.firebase.database.FirebaseDatabase

class UpdateCategoryActivity : AppCompatActivity() {

    private lateinit var btnDeleteCategory: Button
    private lateinit var categoryId: String
    private lateinit var categoryNameEditText: EditText
    private lateinit var categoryDescriptionEditText: EditText
    private lateinit var database: FirebaseDatabase

    private var selectedCategory: Category? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_update_category)

        database = FirebaseDatabase.getInstance()

        // Initialize EditText fields
        categoryNameEditText = findViewById(R.id.etCategoryName)
        categoryDescriptionEditText = findViewById(R.id.etCategoryDescription)

        // Get the category data from the previous activity
        categoryId = intent.getStringExtra("categoryId") ?: ""
        val categoryName = intent.getStringExtra("categoryName") ?: ""
        val categoryDescription = intent.getStringExtra("categoryDescription") ?: ""

        // Set the category data to the EditText fields
        categoryNameEditText.setText(categoryName)
        categoryDescriptionEditText.setText(categoryDescription)

        btnDeleteCategory = findViewById(R.id.btnDeleteCategory)

        // Set a click listener for the delete button
        btnDeleteCategory.setOnClickListener {
            // Delete the category
            deleteCategory(categoryId)
        }


        findViewById<Button>(R.id.btnBack).setOnClickListener {
            finish() // Finish the current activity and return to the previous activity (MainActivity)
        }

        // Update category button click listener
        findViewById<Button>(R.id.btnUpdateCategory).setOnClickListener {
            val updatedCategoryName = categoryNameEditText.text.toString()
            val updatedCategoryDescription = categoryDescriptionEditText.text.toString()

            // Perform the update operation
            updateCategory(categoryId, updatedCategoryName, updatedCategoryDescription)
        }
    }

    private fun updateCategory(categoryId: String, categoryName: String, categoryDescription: String) {
        val categoriesRef = database.getReference("category")
        val categoryRef = categoriesRef.child(categoryId)

        val updatedCategory = mapOf(
            "name" to categoryName,
            "description" to categoryDescription
        )

        categoryRef.updateChildren(updatedCategory)
            .addOnSuccessListener {
                // Category update succeeded
                Toast.makeText(this, "Category updated successfully", Toast.LENGTH_SHORT).show()
                finish() // Finish the activity and go back to the previous activity
            }
            .addOnFailureListener {
                // Category update failed
                Toast.makeText(this, "Failed to update category", Toast.LENGTH_SHORT).show()
            }
    }


    private fun deleteCategory(categoryId: String) {
        val categoriesRef = database.getReference("category")
        categoriesRef.child(categoryId).removeValue()
            .addOnSuccessListener {
                // Category deletion succeeded
                Toast.makeText(this, "Category deleted successfully", Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener {
                // Category deletion failed
                Toast.makeText(this, "Failed to delete category", Toast.LENGTH_SHORT).show()
            }
    }
    private fun setCategory(category: Category) {
        selectedCategory = category
    }

    private fun getCurrentSelectedCategory(): Category? {
        return selectedCategory
    }

}
