package com.example.opscpoe3


data class Category(
    val name: String,
    val description: String
)
