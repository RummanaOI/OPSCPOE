package com.example.opscpoe3

//Adapted from: JavaTPoint Data Class
data class Users(
    val name: String,
    val email: String,
    val username: String,
    val password: String,
    val minGoal: String,
    val maxGoal: String)


//Adapted from : https://www.javatpoint.com/kotlin-data-class// JavaTPoint // 2021