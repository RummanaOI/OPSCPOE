package com.example.opscpoe3
//(Color Picker Android Studio Kotlin Custom Spinner Tutorial, 2021)
class ColorObject(var name:String, var hex:String, contrastHex:String) {
    val hexHash : String = "#$hex"
    val contrastHexHash : String = "#$contrastHex"
}
//(Color Picker Android Studio Kotlin Custom Spinner Tutorial. (2021, October 8). [Video]. Youtube. Retrieved June 6, 2023, from https://www.youtube.com/watch?v=YsKjl8ZbM4g